
	<?php  
	require_once 'core/init.php';
    include 'includes/head.php';
    include  'includes/headerfull.php';
    include  'includes/leftbar.php'; ?>
    <!-- Navigation -->
    <?php include_once 'includes\navigation.php'; ?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Side Bar -->
			
			

<div class="col-md-6 col-sm-6 col-xs-12">
    <form action="" method="post">
     <div class="form-group ">
      <label class="control-label requiredField" for="username">
       User Name
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="username" name="username" placeholder="David" type="text" required />
      <span class="help-block" id="hint_fname">
       Enter Your First Name
      </span>
     </div>

   
     <div class="form-group ">
      <label class="control-label requiredField" for="email">
       Email
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="email" name="email" placeholder="Email" type="email" required />
      <span class="help-block" id="hint_email">
       Enter your email address
      </span>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="password">
       Password
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="password" name="password" placeholder="Password" type="password" required />
      <span class="help-block" id="hint_password">
       Enter Your Password
      </span>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="gender">
       Gender
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="gender" name="gender">
       <option value="Male">
        Male
       </option>
       <option value="Female">
        Female
       </option>
      </select>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="postalcode" required />
       Postal Code
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="postalcode" name="postalcode" type="text" required />
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="address">
       Address
       <span class="asteriskField">
        *
       </span>
      </label>
      <textarea class="form-control" cols="40" id="address" name="address" placeholder="Enter your address" rows="10"></textarea>
      <span class="help-block" id="hint_address" required />
       Enter Your Full Address
      </span>
     </div>
     <div class="form-group">
      <div>
       <button class="btn btn-primary " name="submit" type="submit">
        Create
       </button>
      </div>
     </div>
    </form>
   </div>
			<div class="col-md-4">
			</div>
        </div>

    </div>
    <!-- /.container -->
	<?php 
			
		 ?>
<?php 

	if($_POST){
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$gender = $_POST['gender'];
		$postalCode = $_POST['postalcode'];
		$address = $_POST['address'];
		
				// User Name validation :
		if(!isset($_POST['username']) || $_POST['username'] == ''){
			echo  '<script>alert("Please type your name. Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>'; 
			
			$checkFlag = FALSE;
     	}
		
		if (is_numeric($_POST['username'])) {
			echo  '<script>alert("User Name can not contain numeric value. Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			
			$checkFlag = FALSE;
		}
		
		if (preg_match(('/\s/'),$_POST['username'])) {
			echo  '<script>alert("User Name can not contain space. Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			
			$checkFlag = FALSE;
		}
		
		 // postcode validation ;
		 
		if(!isset($_POST['postalcode']) || $_POST['postalcode'] == '' || strlen($_POST['postalcode']) != 4){
			echo  '<script>alert("Please type your postalcode. Postcode must contain 4 digit . Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			
			$checkFlag = FALSE;
	     } 
		 
		 if (!is_numeric($_POST['postalcode'])) {
			echo  '<script>alert("Post code must be numeric value . Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			
			$checkFlag = FALSE;
		}
		 
		 //Address validation:
		 
		 if(!isset($_POST['address']) || $_POST['address'] == ''){
			 echo  '<script>alert("Please type your address . Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			 
			$checkFlag = FALSE;
	     }
		 
		 // Password validation:
		
	    if(!isset($_POST['password']) || $_POST['password'] == ''){
			echo  '<script>alert("Please type your password. Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			
			$checkFlag = FALSE;
	     }
		 
		if (strlen ($_POST['password']) < 8){
		  echo  '<script>alert("Password can not be less than 8 . Please fill up regisration form again."); window.location.href = "http://localhost/1ST/signup.php";</script>'; 
		  
		  $checkFlag = FALSE;
		}
			
			// Email validation:
		 
    	if(!isset($_POST['email']) || ($_POST['email'] == '')){
			echo  '<script>alert("Please type your email. Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';

			$checkFlag = FALSE;
	    }
		
		if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
			  echo  '<script>alert("Please provide a valid email address. Fill up the registration form again!!!"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			  
			 $checkFlag = FALSE; 
			}
			
				
		
		include_once 'dbCon.php';	
		$conn = connect();
		
		$sql = "SELECT * FROM user_info WHERE email='$email'";
		$result = $conn->query($sql);
			
			if($result->num_rows <= 0){
			$sql = "INSERT INTO user_info(username,email,password,gender,postcode,address)
			VALUES ('$username','$email','$password','$gender','$postalCode','$address');";
				
					if($conn->query($sql)){
						echo  '<script>alert("You are Registered Successfully"); window.location.href = "http://localhost/1ST/login.php";</script>'; 
							
					}else{
					echo  '<script>alert("Something went wrong. Please try later."); window.location.href = "http://localhost/1ST/login.php";</script>';
					}
			}
			
			else
			
			{
				echo  '<script>alert("email already exist. Try again with different email"); window.location.href = "http://localhost/1ST/signup.php";</script>';
			
			}	
		
	}

	
	include_once 'includes\footer.php'; 
?>