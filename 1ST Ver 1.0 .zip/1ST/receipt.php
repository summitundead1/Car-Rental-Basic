<?php include 'core/init.php'?>
<?php include 'includes/head.php'?>
 <?php include 'includes/headerfull.php'?> 
 <?php include 'includes/navigation.php'?>
 <?php include 'includes/leftbar.php'?>

<?php 
	
	include_once 'dbCon.php';
	$conn= connect();
	
      if(isset($_GET['id'])){
		$id = $_GET['id'];
		$sql= "SELECT * FROM user_info JOIN booking_details ON user_info.user_id = booking_details.user_id WHERE p_ID=$id";
		
		$resultData=$conn->query($sql);
		foreach($resultData as $items){
			$id = $items['p_ID'];
			$product_title = $items['product_title'];
			$end_date = $items['end_date'];
			$start_date = $items['start_date'];
			$mobno = $items['mobno'];
			$totalPrice = $items['totalprice'];
			$id = $items['user_id'];
			$unitprice = $items['product_price'];
			$username = $items['username'];
	
	
	$x = strtotime ($items['start_date']);
				//echo $x ;exit;
				$y = strtotime ($items['end_date']);
				$D = $y - $x;
				$totalday = floor ( $D/(60*60*24));
				
				
			//echo $username; exit;
			
		}
		
	  }
	  
	 
	  
	
	?>
<div class="container">
<form action="" method="POST" >
    <div class="row">
        <div class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <address>
                        <strong><?php echo $username ?></strong>
						<br>
                        <abbr title="Phone">Mobile No:</abbr> <?php echo $mobno ?>
                    </address>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
					<p>
                        <em>Receipt #: <?php echo $id ?></em>
                    </p>
                    <p>
                        <strong>Today's date:</strong>
						<input name="Date" readonly = "readonly" value="<?php echo date('d/m/y');?>"/>
                    </p>
                    
                </div>
            </div>
            <div class="row">
                <div class="text-center" method = "POST" >
                    <h1>Receipt</h1>
                </div>
                </span>
                <table class="table table-hover" method = "POST">
                    <thead>
                        <tr>
                            <th>Product Title</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th class="text-center">Unit Price</th>  
                            <th class="text-center">Total Day</th>  
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="col-md-3"><em><?php echo $product_title ?></em></h4></td>
                            <td class="col-md-2" style="text-align: center"> <?php echo $start_date ?> </td>
                            <td class="col-md-2 text-center"><?php echo $end_date ?></td>
                            <td class="col-md-2 text-center">$<?php echo $unitprice ?></td>
                            <td class="col-md-1 text-center"><?php echo $totalday ?></td>
                        </tr>
                        <tr>
                            <td>   </td>
                            <td>   </td>
							<td>   </td>
                            <td class="text-right"><h4><strong>Total: </strong></h4></td>
                            <td class="text-center text-danger"><h4><strong>$<?php echo $totalPrice ?></strong></h4></td>
                        </tr>
                    </tbody>
                </table>
				
                <input type="button"  name="submit" id="submit" class="btn btn-success btn-lg btn-block" onclick="window.location='http://localhost/1ST/index.php'" value="Done"/>
                </td>
				</form>
            </div>
        </div>
    </div>
	
	<style>
	body {
    margin-top: 20px;
}
</style>