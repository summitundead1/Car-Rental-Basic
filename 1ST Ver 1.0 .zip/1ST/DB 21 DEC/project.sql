-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2018 at 11:46 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.0.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_details`
--

CREATE TABLE `booking_details` (
  `p_ID` int(50) NOT NULL,
  `username` varchar(70) NOT NULL,
  `mobno` varchar(15) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_description` varchar(100) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `product_id` int(50) NOT NULL,
  `totalprice` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking_details`
--

INSERT INTO `booking_details` (`p_ID`, `username`, `mobno`, `start_date`, `end_date`, `product_price`, `product_description`, `product_title`, `image`, `Brand`, `product_id`, `totalprice`) VALUES
(1, 'a', '01683182337', '2018-01-01', '2018-01-02', 6000, 'STRONG', 'Mercedes-Benz E400', '/1ST/images/products2/merce400.jpg', '', 0, 0),
(2, 'a', '01683182337', '2018-01-02', '2018-01-25', 10000, 'Ultra Comfort', '2012 Toyota Hiace Super LWB Manual', '/1ST/images/products2/hiace.jpg', '', 0, 0),
(3, 'a', '01683182337', '2018-01-11', '2018-01-02', 8000, 'Extra Rigid', '2017 Toyota Sienna Limited Premium', '/1ST/images/products2/sienna2017.jpg', '', 0, 0),
(4, 'a', '01683182337', '2018-01-09', '2018-01-16', 20000, 'LUXURY', '2017 Mercedes-Benz Metris Passenger', '/1ST/images/products2/metris2017.jpg', '', 0, 0),
(5, 'a', '01683182337', '2018-01-17', '2018-01-09', 3000, 'RIDER', ' Mercedes-Benz C200', '/1ST/images/products2/mercc200.jpg', '', 0, 0),
(6, 'a', '01683182337', '2018-01-15', '2018-01-22', 6000, 'Classy', '2011 Mercedes-Benz C250 Avantgarde', '/1ST/images/products2/mercc250.jpg', '2', 0, 0),
(7, 'a', '01683182337', '2018-01-24', '2018-01-02', 6000, 'Classy', '2011 Mercedes-Benz C250 Avantgarde', '/1ST/images/products2/mercc250.jpg', 'Mercedes', 0, 0),
(8, 'a', '01683182337', '2018-01-29', '2018-01-01', 20000, 'Ultra Rider', '2017 Toyota Vellfire', '/1ST/images/products2/vellfire.jpg', 'Toyota', 0, 0),
(9, 'a', '01683182337', '2018-01-10', '2018-01-10', 8000, 'These cars are amazing', '2017 Toyota Sienna Limited Premium', '/1ST/images/products2/sienna2017.jpg', 'Toyota', 1, 0),
(10, 'a', '01683182337', '2018-01-11', '2018-01-03', 6000, 'STRONG', 'Mercedes-Benz E400', '/1ST/images/products2/merce400.jpg', 'Mercedes', 8, 0),
(11, 'a', '01683182337', '2018-01-11', '2018-01-26', 12000, 'ARISTOCRAT', '2016 Mercedes-Benz S400 L Auto', '/1ST/images/products2/mercs400.jpg', 'Mercedes', 10, 0),
(12, 'a', '01683182337', '2018-01-24', '2018-01-27', 6000, 'STRONG', 'Mercedes-Benz E400', '/1ST/images/products2/merce400.jpg', 'Mercedes', 8, 0),
(13, 'Tan', '01683182337', '2018-01-18', '2018-01-20', 20000, 'LUXURY', '2017 Mercedes-Benz Metris Passenger', '/1ST/images/products2/metris2017.jpg', 'Mercedes', 4, 40000);

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `Id` int(11) NOT NULL,
  `Brand` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`Id`, `Brand`) VALUES
(1, 'BMW'),
(2, 'Mercedes'),
(4, 'NISSAN'),
(5, 'JEEP'),
(9, 'Toyota'),
(11, 'kopa'),
(12, 'samsu'),
(13, 'JEEPAR');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Parent` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `Parent`) VALUES
(1, 'Sedan', 0),
(2, 'Saloon', 0),
(3, 'Jeep', 0),
(4, 'SUV', 0),
(5, 'Vans', 0),
(6, 'Ultimate Royal', 0),
(7, 'BMW X Series', 4),
(8, 'Crown Athlete', 6),
(11, 'Mercedes CLA45 AMG', 9),
(12, 'BMW M5', 10),
(13, 'LAND ROVER ', 3),
(14, 'LAND ROVER SUV', 4),
(15, 'LAND CRUISER', 0),
(16, 'LAND CRUISER PRADO', 15),
(17, 'LAND CRUISER V8', 15),
(31, 'BMW Sedan 3 Series', 1),
(32, 'BMW Sedan 5 Series', 1),
(33, 'BMW Sedan M Series', 1),
(34, 'BMW Sedan 7 Series', 1),
(35, 'Mercedes-Benz C Class', 2),
(36, 'Mercedes-Benz E Class', 2),
(37, 'Mercedes-Benz CL Class', 2),
(38, 'Mercedes-Benz S Class', 2),
(39, 'TOYOTA HIACE SERIES', 5),
(40, 'MERCEDES-BENZ VANS', 5),
(41, 'TOYOTA VELLFIRE', 5),
(42, 'TOYOTA SIENNA', 5),
(43, 'Nissan Patrol', 15),
(44, 'Nissan SUV', 4),
(45, 'Toyota SUV', 4);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Price` decimal(10,0) NOT NULL,
  `list_price` decimal(10,0) NOT NULL,
  `Brand` int(11) NOT NULL,
  `Categories` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `feature` tinyint(4) NOT NULL DEFAULT '0',
  `colors` text COLLATE utf8_unicode_ci NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `Price`, `list_price`, `Brand`, `Categories`, `image`, `description`, `feature`, `colors`, `deleted`) VALUES
(1, '2017 Toyota Sienna Limited Premium', '8000', '12000', 9, '5', '/1ST/images/products2/sienna2017.jpg', 'These cars are amazing', 1, 'WHITE:10,Black:5,Blue:1', 0),
(2, '2012 Toyota Hiace Super LWB Manual', '10000', '15000', 9, '39', '/1ST/images/products2/hiace.jpg', 'Ultra Comfort', 1, 'WHITE:3,Black:5,Blue:1', 0),
(3, '2017 Toyota Sienna Limited Premium', '8000', '12000', 9, '42', '/1ST/images/products2/sienna2017.jpg', 'Extra Rigid', 1, 'WHITE:3,Black:5,Blue:1', 0),
(4, '2017 Mercedes-Benz Metris Passenger', '20000', '25000', 2, '40', '/1ST/images/products2/metris2017.jpg', 'LUXURY', 1, 'WHITE:3,Black:5,Blue:1', 0),
(5, '2017 Toyota Vellfire', '20000', '25000', 9, '41', '/1ST/images/products2/vellfire.jpg', 'Ultra Rider', 1, 'WHITE:3,Black:5,Blue:1', 0),
(6, ' Mercedes-Benz C200', '3000', '5000', 2, '35', '/1ST/images/products2/mercc200.jpg', 'RIDER', 1, 'WHITE:3,Black:5,Blue:1', 0),
(7, '2011 Mercedes-Benz C250 Avantgarde', '6000', '8000', 2, '35', '/1ST/images/products2/mercc250.jpg', 'Classy', 1, 'WHITE:3,Black:5,Blue:1', 0),
(8, 'Mercedes-Benz E400', '6000', '8000', 2, '36', '/1ST/images/products2/merce400.jpg', 'STRONG', 1, 'WHITE:3,Black:5,Blue:1', 0),
(9, '2017 Mercedes-Benz CLS250 d', '10000', '12000', 2, '37', '/1ST/images/products2/merccls250d.jpg', 'RUGGED', 1, 'WHITE:3,Black:5,Blue:1', 0),
(10, '2016 Mercedes-Benz S400 L Auto', '12000', '15000', 2, '38', '/1ST/images/products2/mercs400.jpg', 'ARISTOCRAT', 1, 'WHITE:3,Black:5,Blue:1', 0),
(11, 'Mercedes CLA45 AMG', '10000', '12000', 2, '37', '/1ST/images/products2/merccla45.jpg', 'FAST', 1, 'WHITE:3,Black:5,Blue:1', 0),
(12, '2016 BMW 535d M Sport F10 LCI Auto', '10000', '15000', 1, '32', '/1ST/images/products2/bmw535d.jpg', 'SPORT', 1, 'WHITE:3,Black:5,Blue:1', 0),
(13, 'BMW 535i Luxury Line F10 LCI Auto ', '12000', '15000', 1, '32', '/1ST/images/products2/bmw535di.jpg', 'NIBBLE', 1, 'WHITE:3,Black:5,Blue:1', 0),
(14, 'BMW 7 Series Auto ', '20000', '25000', 1, '34', '/1ST/images/products2/bmw7.jpg', 'Reliable', 1, 'WHITE:3,Black:5,Blue:1', 0),
(15, 'BMW M5', '20000', '25000', 1, '33', '/1ST/images/products2/bmwm5.jpg', 'Sport Series', 1, 'WHITE:3,Black:5,Blue:1', 0),
(16, 'test 1', '555', '999', 2, '38', '/1ST/images/products/5418ed4aa5745c8ffed236255be3ffe3.jpg', 'kopa', 0, 'e:2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(175) NOT NULL,
  `password` varchar(255) NOT NULL,
  `join_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime NOT NULL,
  `permissions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `join_date`, `last_login`, `permissions`) VALUES
(1, 'Summit Dutta', 'test@gmail.com', '$2y$10$hMUray33u1mazlhUj7Yzb.FpN7ZGT71KFTv1/P2/8qWZnZ3LbjOBe', '2017-12-23 07:07:11', '2018-01-05 17:02:20', 'admin,editor'),
(2, 'kopa', 'test1@gmail.com', ' $2y$10$y.BM6GzZX6UHIRTs2sIgZ.DLvPmxEwsVECF.z1JK1sQfqev6XQE7K ', '2017-12-23 09:56:07', '2017-12-13 00:00:00', 'admin,editor'),
(3, 'a', 'sonnet@daffodil.ac', '$2y$10$5LJfM.mJ3f5Dg1HSk.87nOd8fcN2SFT1YvIy41nDBmyvIYMRnIJGi', '2017-12-24 19:06:13', '2017-12-24 21:18:05', 'admin,editor');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `username` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `postcode` int(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `gender` varchar(10) NOT NULL COMMENT 'male = 1 , female = 2 , Other = 3 	',
  `password` varchar(50) NOT NULL,
  `user_role` int(5) NOT NULL DEFAULT '0' COMMENT 'admin = 1 , user = 0 '
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `username`, `email`, `postcode`, `address`, `gender`, `password`, `user_role`) VALUES
(1, 'a', 'sonnet@daffodil.ac', 1029, 'k', 'Male', '1234', 0),
(2, 'Tan', 'tan@gmail.com', 1000, 'Dhaka', 'Male', '1234', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_details`
--
ALTER TABLE `booking_details`
  ADD PRIMARY KEY (`p_ID`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_details`
--
ALTER TABLE `booking_details`
  MODIFY `p_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
