

$(document).ready(function(){

	$("#date").datepicker({


		beforeShowDay: function(date)
		{
		var day  = date.getDay();
		var month = date.getMonth();
		var currDate = date.getDate();
		if(day ==1 || day == 5){
			return [true];
		}
		else if(month == 0 && currDate ==1){
			return [true];
		}
		else {
			return[false];
		}

}
	});
});

