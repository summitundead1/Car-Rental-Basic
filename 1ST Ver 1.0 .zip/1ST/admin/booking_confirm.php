
<?php
    require_once '../core/init.php';
    if (!is_logged_in()){
        header("Location: login.php");
    }

    include 'includes/head.php';
    include  'includes/navigation.php';
    include  'confirm_code.php';

?>
	


		
                            <div>
							<form id="" action="confirm_code.php" method="POST" >
									<table class="table table-bordered table-inverse">
										<tr>
											<th>User Name</th>
											<th>Mobile Number</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Unit Price</th>
											<th>Product Description</th>
											<th>Product Title</th>	
											<th>Brand</th>	
											<th>Total Price</th>	
									 			
										</tr>
										
										<?php
										include_once '../dbCon.php';
	                                    $conn= connect();
										$sql= "SELECT * FROM user_info JOIN booking_details ON user_info.user_id = booking_details.user_id  where `confirmation`= ''";
			                            $resultData=$conn->query($sql);
										foreach($resultData as $view){ ?>
										<tr>
											<td><?=$view['username']?></td>
											<td><?=$view['mobno']?></td>
											<td><?=$view['start_date']?></td>
											<td><?=$view['end_date']?></td>
											<td>$<?=$view['product_price']?></td>
											<td><?=$view['product_description']?></td>
											<td><?=$view['product_title']?></td>
											<td><?=$view['Brand']?></td>
											<td>$<?=$view['totalprice']?></td>
											<td><a href="confirm_code.php?id=<?=$view['p_ID']?>" class="btn btn-xs btn-warning" name="confirm" id="confirm">Confirm</a></td>
											
										</tr>
										
										<?php } ?>
									</table>
									</form>
							</div>
							
							<?php

    include 'includes/footer.php';

?>
  
 
			