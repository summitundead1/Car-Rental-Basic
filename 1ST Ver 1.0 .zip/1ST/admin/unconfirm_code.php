<?php 

	
	
	include_once '../dbCon.php';
	$conn= connect();
				
				//Echo 'fffff';exit;
				if(isset($_GET['id'])){
					
				$id = $_GET['id'];
				
				 $sql = "UPDATE `booking_details` SET `confirmation`= '' WHERE p_ID=$id";
				
				$conn->query($sql);
				
				
			
			
			
    
	 
					
	
	 
		
				
				echo  '<script>alert("Booking Successfully UnConfirmed."); window.location.href = "http://localhost/1ST/admin/booking_unconfirm.php";</script>';
	 
	 
			
		}	
			
			
						
			 
			 
		
?>