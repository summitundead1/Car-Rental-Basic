<?php 

	
	
	include_once '../dbCon.php';
	$conn= connect();
				
				//Echo 'fffff';exit;
				if(isset($_GET['id'])){
					
				$id = $_GET['id'];
				
				 $sql = "UPDATE `booking_details` SET `confirmation`= 'Confirm' WHERE p_ID=$id";
				
				$conn->query($sql);
				
				
			
			
			
    require_once 'mailSender.php';
	 
					
	$sql= "SELECT * FROM user_info JOIN booking_details ON user_info.user_id = booking_details.user_id WHERE confirmation='Confirm' ";
	         
	$resultData=$conn->query($sql);
	foreach($resultData as $items){
	     
	//echo $gmail; exit;
	
	$toMail = 'tanveershuvos@gmail.com';
	//echo $toMail ; exit;
	$nameOfReciver = $items['username'];
	$productTitle = $items['product_title'];
	$startDate =  $items['start_date'];
	$endDate = $items['end_date'];
	$Totalprice = $items['totalprice'];
	
	//echo $toMail ;exit;
	
	
	$message = '<html><body>Product Title:'.$productTitle.'.......
											Price : $'.$Totalprice.'......
											Starting Date :'.$startDate.'.........
											Ending Date :'.$endDate.'.........
											
											For further information about payment stay with us.
											<admin>
											</body></html>';

						sendMail($toMail,$nameOfReciver,'Booking Confirm',$message);
						//sendMail('tanveershuvos@gmail.com','Tanvir','Test mail','mail body for test');
						
						//echo $message ; exit;
				}
				
				echo  '<script>alert("Booking Successfully Confirmed. A mail has been gone to the customers gmail."); window.location.href = "http://localhost/1ST/admin/booking_confirm.php";</script>';
	 
	 }

			
			
			
			
						
			 
			 
		
?>