
<?php
    require_once '../core/init.php';
    if (!is_logged_in()){
        header("Location: login.php");
    }

    include 'includes/head.php';
    include  'includes/navigation.php';

?>
<?php 
	include_once '../dbCon.php';
	$conn= connect();

	if(isset($_POST['done'])){
		
			$productTitle= $_POST['product_title'];
			$endDate= $_POST['end_date'];
			$startDate= $_POST['start_date'];
			$mobNo= $_POST['mob_no'];
			$totalPrice= $_POST['total_price'];
				
			$id = $_POST['p_ID'];
				
			$sql = "UPDATE `booking_details` SET `product_title`='$productTitle',`end_date`='$endDate',`start_date`='$startDate',`mobno`='$mobNo',`totalprice`='$totalPrice' WHERE `p_ID`=$id";
			
			
			$conn->query($sql);
			
			//echo 'ghghgh';exit;
			
				echo  '<script>alert("Booking editing successful"); window.location.href = "http://localhost/1ST/admin/edit_booking.php";</script>';
				
			}
	
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$sql= "SELECT * from `booking_details` WHERE p_ID=$id";
		
		$resultData=$conn->query($sql);
		foreach($resultData as $items){
			$id = $items['p_ID'];
			$product_title = $items['product_title'];
			$end_date = $items['end_date'];
			$start_date = $items['start_date'];
			$mobno = $items['mobno'];
			$totalPrice = $items['totalprice'];
			
		}
	}
	
		$sql= "SELECT * from booking_details";
			$result=$conn->query($sql);
	
	
?>

	<head>

<h1 align="center"> Edit Booking date/Time</h1></br>
</head>
<body>
	<div align="center">
	<div class="row text-center">
          
	                       <form autocomplete="on" method="post"> 
						   
						   <input type="hidden" name="p_ID" value="<?php if(isset($id)) echo $id; ?>">
							
					
                                <p> 
									<h4>Edit Product Title</h4>
                                    <input id="product_title" name="product_title" type="text" value="<?php if(isset($product_title)) echo $product_title; ?>">
                                    
									<h4>Edit End Date</h4>
                                    <input id="end_date" name="end_date" type="date" value="<?php if(isset($end_date)) echo $end_date; ?>">
									
									<h4>Edit Start Date</h4>
                                    <input id="start_date" name="start_date" type="date" value="<?php if(isset($start_date)) echo $start_date; ?>">
									
									<h4>Edit Mobile No</h4>
                                    <input id="mob_no" name="mob_no" type="text" value="<?php if(isset($mobno)) echo $mobno; ?>">
									
									<h4>Edit Total Price</h4>
                                    <input id="total_price" name="total_price" type="text" value="<?php if(isset($totalPrice)) echo $totalPrice; ?>"><br>
									
									<p> <br>
									<input type="submit" class="btn btn-primary btn-lg" name="done" value="Done"/> 
								</p>
									

						</form>
		
		   
							   
							   </div>
 </div> 
		
		
		
		
						<div id="content" align="center">
		                    <table class="table table-bordered table-inverse">
										<tr>
											<th>Product Title</th>
											<th>End Date</th>
											<th>Start Date</th>
											<th>Mobile No</th>
											<th>Total price</th>
											<th>Action</th>
											
										</tr>
										<?php foreach($result as $row){ ?>
										<tr>
											<td><?=$row['product_title']?></td>
											<td><?=$row['end_date']?></td>
											<td><?=$row['start_date']?></td>
											<td><?=$row['mobno']?></td>
											<td>$<?=$row['totalprice']?></td>
											<td><a href="edit_booking.php?id=<?=$row['p_ID']?>" class="btn btn-xs btn-warning">Edit</a></td>
										</tr>
										<?php  } ?>
									</table>
								</div>
	
	
</div>
							
	</body>		

<?php
//    
    include 'includes/footer.php';

?>	
		
    
	
							
							
			
			
			
			