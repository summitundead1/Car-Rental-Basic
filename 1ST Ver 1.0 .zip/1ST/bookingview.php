<?php include 'core/init.php'?>
<?php include 'includes/head.php'?>
 <?php include 'includes/headerfull.php'?> 
 <?php include 'includes/navigation.php'?>
 <?php include 'includes/leftbar.php'?>

 
 <?php 
 
 include_once 'dbCon.php';
	$conn= connect();

		
		if(isset($_GET['id'])){
			$p_id = $_GET['id'];
			$sql= "SELECT * from products WHERE id='$p_id'";
			echo $sql;exit;
			$resultData=$conn->query($sql);
			//echo $resultData;exit;
			$bookinfo=mysqli_fetch_assoc($resultData);
			
		}
 
 ?>
 
  <div>
   <h1 align="center">Your Booking Information </h1>
									<table class="table table-bordered table-inverse ">
										<tr>
											<th>User Name</th>
											<th>Start Date</th>
											<th>ENd Date</th>
											<th>Mobile Number</th>
											<th>Unit Price</th>
											<th>Total price</th>
											<th>Product Description</th>
											<th>Product title</th>
											<th>Brand</th>
											<th>Product image</th>
											<th>Confirmation</th>
											
									 			
										</tr>
										<?php 
										
										$uname= $_SESSION['name'];
										
										//echo $uname ;exit;
										
										$sql= "SELECT * from booking_details WHERE username='$uname'";
											//echo $sql;exit;
											$resultData=$conn->query($sql);
											//echo $resultData;exit;
											$bookinfo=mysqli_fetch_assoc($resultData);
											foreach ($resultData as $row){
												
											?>
										
										<tr>
											<td><?=$row['username']?></td>
											<td><?=$row['start_date']?></td>
											<td><?=$row['end_date']?></td>
											<td><?=$row['mobno']?></td>
											<td><?=$row['product_price']?></td>
											<td><?=$row['totalprice']?></td>
											<td><?=$row['product_description']?></td>
											<td><?=$row['product_title']?></td>
											<td><?=$row['Brand']?></td>
										    <td><img src="<?=$row['image']?>" width="200"></td>
										    <td><?=$row['confirmation']?></td>
												
										</tr>
										
											<?php } ?>
										
										
							        	
									</table>
									<div align="center">
									<a href="index.php" class='btn btn-info col-lg-6'>Back to Homepage</a>
									</div>
							</div>
<?php
//    include 'includes/detailsmodal.php';
    include 'includes/rightbar.php';
    include 'includes/footer.php';

?>