<?php 
	
	include_once 'dbCon.php';
	$conn= connect();
 
	 if(isset($_POST['book_now'])){
		//session_start();
			$okFlag = TRUE;
			//$startDate = $_POST['start_date'].'<br>';
			//$date = new DateTime($startDate);
			////echo $date->format('Y-m-d').'<br>';
		//echo date('Y-m-d');exit;
		
		if(!isset($_POST['start_date']) || $_POST['start_date'] == ''){
			echo  '<script>alert("Please select start date"); window.location.href = "http://localhost/1ST/booking.php";</script>';
			$okFlag = FALSE;
		}
		if(!isset($_POST['end_date']) || $_POST['end_date'] == ''){
			echo  '<script>alert("Please select end date"); window.location.href = "http://localhost/1ST/booking.php";</script>';
			$okFlag = FALSE;
		}
		
		if(!isset($_POST['mob_no']) || $_POST['mob_no'] == ''|| strlen($_POST['mob_no']) != 11){
			echo  '<script>alert("Please check your conatct info and insert again"); window.location.href = "http://localhost/1ST/booking.php";</script>';
			$okFlag = FALSE;
		}
		
		
		
		if (!is_numeric($_POST['mob_no'])) {
			echo  '<script>alert("Mobile number cannot contain letter!!! try again"); window.location.href = "http://localhost/1ST/booking.php";</script>';
			
			$okFlag = FALSE;
		}
		
		
		
		
		if($okFlag){
			//echo $_POST['package_id'];exit;
			$ID = $_POST['product_id'];
			$StartDate= date('Y-m-d',strtotime($_POST['start_date']));
			$EndDate= date('Y-m-d',strtotime($_POST['end_date']));
			$prTitle= $_POST['pr_title'];
			$prPrice= $_POST['pr_price'];
			$prDescription= $_POST['pr_description'];
			$mobnum= $_POST['mob_no'];
			$prImage= $_POST['image'];
			$userID=$_SESSION['id'];
			$userName=$_SESSION['name'];
			
			
		    $id = $_POST['pr_brand'];
		    $query="select * from brand where `Id`=$id";
		    //echo $query;exit;
		    $vie = $conn->query($query);
		    $view=mysqli_fetch_assoc($vie);
			$Brand = $view['Brand'];
			
			
			
			
			
			
			$sql = "SELECT * FROM `booking_details` WHERE `start_date`='$StartDate' AND `product_id`='$ID'";
			
			
			
	        $result=$conn->query($sql);
			//echo $sql;exit;
	        if($result->num_rows > 0){
				//echo $ID;exit;
				echo  '<script>alert("This date is booked for this product . Please select another date"); window.location.href = "http://localhost/1ST/booking.php?id='.$ID.'";</script>';
				
	     	}else{
	     	
				$x = strtotime ($_POST['start_date']);
				//echo $x ;exit;
				$y = strtotime ($_POST['end_date']);
				$D = $y - $x;
				$totalday = floor ( $D/(60*60*24));
				
				//echo $totalday;exit;
				
				$totalPrice = $totalday * $prPrice ;
				
				//echo $totalPrice;exit;
				
				
			
				$sql= "INSERT INTO `booking_details` (`username`,`user_id`,`mobno`, `start_date`,`end_date`,`product_price`,`product_description`,`product_title`,`image`,`Brand`,`product_id`,`totalprice`) 
				VALUES ('$userName','$userID','$mobnum','$StartDate', '$EndDate','$prPrice','$prDescription','$prTitle','$prImage','$Brand','$ID','$totalPrice');";
				
				//echo $sql;exit;
				
				if($conn->query($sql)){
						
					echo  '<script>alert("Booking succesfull. Please check you gmail account for confirmation mail."); window.location.href = "http://localhost/1ST/booking_form.php";</script>';
				}
				else{
					echo  '<script>alert("Something went wrong"); window.location.href = "http://localhost/1ST/booking.php";</script>';
				}
				
			}
		 
		}			
}	
	 		 
		
?>

