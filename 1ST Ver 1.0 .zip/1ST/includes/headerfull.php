<!-- Header -->
<div id="headerWrapper"></div>
<div id="back-flower"></div>
<div id="logotext"></div>
<div id="fore-flower"></div>

<!-- Left Sidebar -->
<div class="container-fluid">
