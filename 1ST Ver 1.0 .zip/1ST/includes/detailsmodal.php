<?php
require_once '../core/init.php';
$id = $_POST['id'];
$id = (int)$id;
$sql = "SELECT * FROM products WHERE id = '$id'";
$result = $db->query($sql);
$product = mysqli_fetch_assoc($result);
$brand_id = $product['Brand'];
$sql = "SELECT Brand FROM brand WHERE id = '$brand_id'";
$brand_query = $db->query($sql);
$brand = mysqli_fetch_assoc($brand_query);
$colorString = $product['colors'];
 $colorString = rtrim($colorString,',');
$color_array = explode(',', $colorString);
?>
<!-- Details Light BoxModal -->
<? ob_start(); ?>
<?=$colorString; ?>
<div class="modal fade details-1" id="details-modal" tabindex="-1" role="dialog" aria-labelledby="details-1"
     aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" type="button" onclick="closeModal()" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title text-center"><?= $product['title']; ?></h4>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="center-block">
                                <img src="<?= $product['image']; ?>" alt="<?= $product['title']; ?>" class="details img-responsive">
                                <div>
                                </div>
                                <div class="col-sm-10" align="right">
                                    <h4> Details </h4>
                                    <p> <?= nl2br($product['description']); ?></p>
                                    <hr>
                                    <p> Price: $<?= $product['Price']; ?> </p>
                                    <p>Brand : <?= $brand['Brand']; ?></p>
                                    <form action="add_cart.php" method="post">
                                        <div class="form-group">
                                            <div class="col-xs-5">
                                                 <!--<label for="quantity">Quantity:</label>
                                                <input type="text" class="form-control" id="quantity" name="quantity">
                                            </div>-->
                                        <div class="form-group">
                                            <!--<label for="color" >COLOR:</label>
                                            <select name="color" id="color" class="form-control">
                                                <option value=""></option>
                                                <?php foreach($color_array as $string) {
                                                    $string_array = explode(':', $string);
                                                    $color = $string_array[0];
                                                    $quantity = $string_array[1];
                                                     echo '<option value="'.$color.'">'.$color.'('.$quantity.'Available)</option>';
                                                } ?>

                                            </select>-->
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-default" onclick="closeModal()"> Close</button>
						<?php if(isset($_SESSION['isLoggedIn'])&& $_SESSION['isLoggedIn']==true) { ?>
						<a href="booking.php?id=<?=$product['id']?>" class="btn btn-warning " type="submit">Book Now</a>
						<?php } else { ?>
						<a href="login.php" class="btn btn-danger">Login to Book</a>
						<?php } ?>
                        <!--<button class="btn btn-warning" type="submit"><span
                                class="glyphicon glyphicon-modal-window" onclick="document.location='http://localhost/1ST/booking.php(<?= $product['id']; ?>)"></span> Book Now-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function closeModal() {
      jQuery('#details-modal').modal('hide');
      setTimeout(function () {
          jQuery('#details-modal').remove();
          jQuery('.modal-backdrop').remove();

      },500);
    }
</script>
<?php echo ob_get_clean(); ?>