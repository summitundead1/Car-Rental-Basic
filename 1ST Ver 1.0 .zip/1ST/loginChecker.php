<?php 
//Login checker
session_start();
if($_POST){
	
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	$sql = "SELECT * FROM `user_info` 
			WHERE `email`='$email' 
			AND `password`='$pass'";
			
	//echo $sql;exit;
	require_once 'core/init.php';
	include_once 'dbCon.php';
	
	$con = connect();
	
	$result = $con->query($sql);
	//var_dump($result->num_rows);exit;
	
	if($result->num_rows > 0){
		$_SESSION['isLoggedIn'] = TRUE;
		
		foreach($result as $row){
			$_SESSION['id'] 	= $row['user_id'];
			$_SESSION['email'] 	= $row['email'];
			$_SESSION['name'] 	= $row['username'];
			$_SESSION['role'] 	= $row['user_role'];
		}
		
		//var_dump($_SESSION);exit;
		header('location:index.php');	
		
	}else{
		//remove all session variables
		//session_destroy();
		
		//remove value of all session variables
		session_unset(); 
		$_SESSION['errorMsg'] = 'email or password is wrong';
		header('location:login.php');
		//header('location:login.php?errorMsg=email or password is wrong');
		
	}
}









