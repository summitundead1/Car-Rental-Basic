 <?php  
	require_once 'core/init.php';
    include 'includes/head.php';
    include  'includes/headerfull.php';
    //include  'includes/detailsmodal.php';
    include  'includes/leftbar.php';
	include 'booking_code.php'
	
	
	
	?>
    <!-- Navigation -->
    <?php include_once 'includes\navigation.php'; ?>
 <?php 
 
 include_once 'dbCon.php';
	$conn= connect();
		
		if(isset($_GET['id'])){
			$p_id = $_GET['id'];
			$sql= "SELECT * from products WHERE id='$p_id'";
			//echo $sql;exit;
			$resultData=$conn->query($sql);
			//echo $resultData;exit;
			$bookinfo=mysqli_fetch_assoc($resultData);
			
		}
 
 ?>
 <link href="http://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" rel="stylesheet">
 <script>
 $(document).ready(function (){
	 var minDate = new Date();
	 $("#start").datepicker({
		 showAnim: 'drop',
		 numberOfMonth: 1,
		 minDate: minDate,
		 dateFormat:'yy-mm-dd',
		 onClose: function(selectedDate){
		 $('#return').datepicker("option", "minDate",selectedDate);
		 
		 }
	 });
 });
 
 
 </script>
 <script>
  $(document).ready(function (){
	 var minDate = new Date();
	 $("#end").datepicker({
		 showAnim: 'drop',
		 numberOfMonth: 1,
		 minDate: minDate,
		 dateFormat:'yy-mm-dd',
		 onClose: function(selectedDate){
		 $('#return').datepicker("option", "minDate",selectedDate);
		 
		 }
	 });
 });
 
 
 </script>

 <body >
 <div class="container"></br>
            <section>				
                <div id="container_demo" >
				<div align="center">
				
				<a class="hiddenanchor" id="book_now"></a>
                    <div id="wrapper">
                        <div id="book_now" class="animate form">
							<form id="book_now" action="" method="POST" autocomplete="on" enctype="multipart/form-data">
							<h4>
								<input type="hidden" name="product_id" value="<?php if(isset($p_id)) echo $p_id; ?>">
								<input type="hidden" name="pr_id" value="<?=$bookinfo['id'] ?>">
								<input type="hidden" name="pr_price" value="<?=$bookinfo['Price']?>">
								<input type="hidden" name="pr_description" value="<?=$bookinfo['description']?>">
								<input type="hidden" name="pr_title" value="<?=$bookinfo['title']?>">
								<input type="hidden" name="pr_brand" value="<?=$bookinfo['Brand']?>">
								<input type="hidden" name="image" value="<?=$bookinfo['image']?>">
								
								
								<div> 
									<label>Starting Date:</label></br>
									<input type="text" id="start" name="start_date" min="<?=$toDay?>">
								</div></br>
								
								<div> <label>Ending Date :</label></br>
									<input type="text" id="end" name="end_date" min="<?=$toDay?>">
								</div></br>
								
                                <div> 
								    <label>Please give you contact number : (Must be 11 Digit)</label></br>
                                    <input type="text" name="mob_no" placeholder="Contact number" value="<?php if(isset($mobnum)) echo $mobnum; ?>">
                                </div></br>
								
								<div class="book now button"> 
									
									<input type="submit" name="book_now" class="btn-info col-md-3" value="Book Now"/>
								</div></br>
								
					</h4>			
					</form>
							
                        </div>	
						
                    </div>
                </div>
				 </div>
            </section>
        </div>
		

<?php
//    include 'includes/detailsmodal.php';
    include 'includes/rightbar.php';
    include 'includes/footer.php';

?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script
  src="http://code.jquery.com/jquery-2.2.4.js"></script>
  <script
  src="http://code.jquery.com/ui/1.12.1/jquery-ui.js"
  integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30="
  crossorigin="anonymous"></script>
                   